<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

            <div class="content-wrapper">
                <section class="content-header">
                    <?php echo $pagetitle; ?>
                    <?php echo $breadcrumb; ?>
                </section>

                <section class="content">
                    <div class="box collapse cart-options" id="collapseExample">
                        <div class="box-header">Filter Categories</div>
                        <div class="box-body categories_dom_wrapper">
                        </div>
                        <div class="box-footer">
                            <button class="btn btn-primary close-item-options pull-right">Hide options</button>
                        </div>
                    </div>   
                    <div class="row gui-row-tag">
                       
                    </div>
                </section>
            </div>
